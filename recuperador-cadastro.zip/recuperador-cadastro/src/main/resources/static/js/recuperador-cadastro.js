var RecuperadorCadastro = RecuperadorCadastro || {};

RecuperadorCadastro.FormataDocumento = (function() {
	
	function FormataDocumento() {
		this.formataCPF  = $('.input-cpf');
		this.formataCNPJ = $('.input-cnpj');
	
	}
	
	FormataDocumento.prototype.enable = function() {
	
		this.formataCPF.mask('000.000.000-00');
		this.formataCNPJ.mask('00.000.000/0000-00');
	}
	
	return FormataDocumento;
	
}());


RecuperadorCadastro.FormataCampos = (function() {
	
	function FormataCampos() {
		this.formataInputAg   = $('.js-numeral-ag');
	    this.formataInputCta  = $('.js-numeral-cta');
	    this.formataIdStelo  = $('.js-numeral-id-stelo');
	}
	
	FormataCampos.prototype.enable = function() {
	
		this.formataInputAg.mask('0000');
		this.formataInputCta.mask('000000000');
		this.formataIdStelo.mask('000000000');
	}
	
	return FormataCampos;
	
}());


RecuperadorCadastro.MaskMoney = (function() {
	
	function MaskMoney() {
		this.decimal = $('.js-decimal');
		this.plain = $('.js-plain');
	}
	
	MaskMoney.prototype.enable = function() {
		this.decimal.maskMoney({ decimal: ',', thousands: '.' });
		this.plain.maskMoney({ precision: 0, thousands: '.' });
	}
	
	return MaskMoney;
	
}());



$(function() {
	
	var formataDocumento = new RecuperadorCadastro.FormataDocumento();
	formataDocumento.enable();
	
	var formataCampos = new RecuperadorCadastro.FormataCampos();
	formataCampos.enable();
	
	var maskMoney = new RecuperadorCadastro.MaskMoney();
	maskMoney.enable();
	
	
    var clipboard = new ClipboardJS('.btn');
    $('[rel="tooltip"]').tooltip();
});



