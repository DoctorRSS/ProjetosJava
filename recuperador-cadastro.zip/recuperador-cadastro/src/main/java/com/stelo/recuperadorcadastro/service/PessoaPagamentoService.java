package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaPagamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaPagamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaPagamentoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaPagamentoRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class PessoaPagamentoService {

	@Autowired
	private PessoaPagamentoHistRepository pessoaPagamentoHistRepository;
	
	@Autowired
	private PessoaPagamentoRepository pessoaPagamentoRepository;
	
	public PessoaPagamentoService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<PessoaPagamentoHistEntity> buscar(Long idStelo){
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaPagamentoHistEntity> listaRelacionamentoHist =
				pessoaPagamentoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaRelacionamentoHist;
	}
	
	@PutMapping
	public void salvar(PessoaPagamentoHistEntity pessoaPagamentoHistEntity) throws ObjetoNuloException {
		PessoaPagamentoEntity pessoaPagamentoEntity;
		try {
			pessoaPagamentoEntity = construirPessoaPagamento(pessoaPagamentoHistEntity);
			pessoaPagamentoRepository.save(pessoaPagamentoEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private PessoaPagamentoEntity construirPessoaPagamento(
			PessoaPagamentoHistEntity pessoaPagamentoHistEntity) throws ObjetoNuloException {
		PessoaPagamentoEntity pessoaPagamentoEntity = new PessoaPagamentoEntity();
		
		if(pessoaPagamentoHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de pessoa pagamento para Alteração!");
		
		pessoaPagamentoEntity.setAtivoCadastroPagto(pessoaPagamentoHistEntity.getAtivoCadastroPagto());
		pessoaPagamentoEntity.setDtAlteracao(pessoaPagamentoHistEntity.getDtAlteracao());
		pessoaPagamentoEntity.setDtInclusao(pessoaPagamentoHistEntity.getDtInclusao());
		pessoaPagamentoEntity.setIdPgtoCadastro(pessoaPagamentoHistEntity.getIdPgtoCadastro());
		pessoaPagamentoEntity.setIdStelo(pessoaPagamentoHistEntity.getIdStelo());
		pessoaPagamentoEntity.setIdUsuarioAlteracao(pessoaPagamentoHistEntity.getIdUsuarioAlteracao());
		pessoaPagamentoEntity.setIdUsuarioInclusao(pessoaPagamentoHistEntity.getIdUsuarioInclusao());
		pessoaPagamentoEntity.setStatus(pessoaPagamentoHistEntity.getStatus());
		
		return pessoaPagamentoEntity;
	}

}
