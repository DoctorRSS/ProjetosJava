package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class PessoaService {

	@Autowired
	private PessoaRepository pessoaRepository;
	
	@Autowired
	private PessoaHistRepository pessoaHistRepository;
	
	public PessoaService() {
		// TODO Auto-generated constructor stub
	}

	@GetMapping
	public List<PessoaHistEntity> buscar(Long idStelo) {
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaHistEntity> listaPessoaHist = 
				pessoaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaPessoaHist;
	}
	
	@PutMapping
	public void salvar(PessoaHistEntity pessoaHistEntity) throws ObjetoNuloException {
		PessoaEntity pessoaEntity = construirPessoa(pessoaHistEntity);
		pessoaRepository.save(pessoaEntity);
	}
	
	private PessoaEntity construirPessoa(PessoaHistEntity pessoaHistEntity) throws ObjetoNuloException {
		PessoaEntity pessoaEntity = new PessoaEntity();
		if(pessoaHistEntity == null) 
			throw new ObjetoNuloException("Não foi informado o histórico de pessoa para Alteração!");
		
		pessoaEntity.setApelido(pessoaHistEntity.getApelido());
		pessoaEntity.setDtAlteracaoPessoa(pessoaHistEntity.getDtAlteracaoPessoa());
		pessoaEntity.setDtCadastroContaStelo(pessoaHistEntity.getDtCadastroContaStelo());
		pessoaEntity.setDtInclusaoPessoa(pessoaHistEntity.getDtInclusaoPessoa());
		pessoaEntity.setFlagCadastroIncompleto(pessoaHistEntity.getFlagCadastroIncompleto());
		pessoaEntity.setIdCanalOrigem(pessoaHistEntity.getIdCanalOrigem());
		pessoaEntity.setIdMotivoBloqueoPessoa(pessoaHistEntity.getIdMotivoBloqueoPessoa());
		pessoaEntity.setIdStatusCadastroUsuario(pessoaHistEntity.getIdStatusCadastroUsuario());
		pessoaEntity.setIdStelo(pessoaHistEntity.getIdStelo());
		pessoaEntity.setIdVip(pessoaHistEntity.getIdVip());
		pessoaEntity.setStatus(pessoaHistEntity.getStatus());
		pessoaEntity.setTpPessoa(pessoaHistEntity.getTpPessoa());
		pessoaEntity.setUsuarioAlteracaoPessoa(pessoaHistEntity.getUsuarioAlteracaoPessoa());
		pessoaEntity.setUsuarioInclusaoPessoa(pessoaHistEntity.getUsuarioInclusaoPessoa());
		return pessoaEntity;
	}
	
}
