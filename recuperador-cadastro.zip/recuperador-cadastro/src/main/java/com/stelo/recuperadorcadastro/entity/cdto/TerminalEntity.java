package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_TERM", schema = "USR_CADU")
public class TerminalEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name="ID_STELO")
	private Long idStelo;

	@Id
	@Column(name="NU_TERM")
	private Long nuTerm; 
	
	@Column(name="TERM_PPRIO_EC")
	private Long termPprioEc;
	
	@Column(name="CD_ADQRE")
	private String cdAdqre;
	
	@Column(name="ID_STTUS_TERM")
	private Long idSttusTerm;
	
	@Column(name="DT_INSTA_TERM")
	private Date dtInstaTerm;
	
	@Column(name="USUAR_INCL")
	private String usuarIncl;
	
	@Column(name="USUAR_ALT")
	private String usuarAlt;
	
	@Column(name="STTUS")
	private Long sttus;
	
	@Column(name="DT_INCL")
	private Date dtIncl;
	
	@Column(name="DT_ALT")
	private Date dtAlt;
	
	@Column(name="ID_TECNO")
	private Long idTecno;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public Long getNuTerm() {
		return nuTerm;
	}

	public void setNuTerm(Long nuTerm) {
		this.nuTerm = nuTerm;
	}

	public Long getTermPprioEc() {
		return termPprioEc;
	}

	public void setTermPprioEc(Long termPprioEc) {
		this.termPprioEc = termPprioEc;
	}

	public String getCdAdqre() {
		return cdAdqre;
	}

	public void setCdAdqre(String cdAdqre) {
		this.cdAdqre = cdAdqre;
	}

	public Long getIdSttusTerm() {
		return idSttusTerm;
	}

	public void setIdSttusTerm(Long idSttusTerm) {
		this.idSttusTerm = idSttusTerm;
	}

	public Date getDtInstaTerm() {
		return dtInstaTerm;
	}

	public void setDtInstaTerm(Date dtInstaTerm) {
		this.dtInstaTerm = dtInstaTerm;
	}

	public String getUsuarIncl() {
		return usuarIncl;
	}

	public void setUsuarIncl(String usuarIncl) {
		this.usuarIncl = usuarIncl;
	}

	public String getUsuarAlt() {
		return usuarAlt;
	}

	public void setUsuarAlt(String usuarAlt) {
		this.usuarAlt = usuarAlt;
	}

	public Long getSttus() {
		return sttus;
	}

	public void setSttus(Long sttus) {
		this.sttus = sttus;
	}

	public Date getDtIncl() {
		return dtIncl;
	}

	public void setDtIncl(Date dtIncl) {
		this.dtIncl = dtIncl;
	}

	public Date getDtAlt() {
		return dtAlt;
	}

	public void setDtAlt(Date dtAlt) {
		this.dtAlt = dtAlt;
	}

	public Long getIdTecno() {
		return idTecno;
	}

	public void setIdTecno(Long idTecno) {
		this.idTecno = idTecno;
	}


}
