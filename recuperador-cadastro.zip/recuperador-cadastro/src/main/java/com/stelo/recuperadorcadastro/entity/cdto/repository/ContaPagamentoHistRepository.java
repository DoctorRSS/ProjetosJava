package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoHistEntity;

@Repository
public interface ContaPagamentoHistRepository extends JpaRepository<ContaPagamentoHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_CTA_PGTO_HIST where id_cta in "
			+ "(select id_cta from USR_CADU.TB_CTA_hist where id_rlcto in "
			+ "(select id_rlcto from USR_CADU.TB_PSSOA_RLCTO_hist where id_stelo = :idStelo) "
			+ "and id_tp_cta = '3') "
			, nativeQuery=true)
	List<ContaPagamentoHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
