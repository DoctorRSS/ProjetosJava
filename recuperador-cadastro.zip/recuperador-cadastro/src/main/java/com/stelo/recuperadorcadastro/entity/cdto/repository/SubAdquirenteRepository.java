package com.stelo.recuperadorcadastro.entity.cdto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteEntity;

@Repository
public interface SubAdquirenteRepository extends JpaRepository<SubAdquirenteEntity, Long> {

}
