package com.stelo.recuperadorcadastro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.TerminalEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TerminalHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TerminalHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TerminalRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class TerminalService {

	@Autowired
	private TerminalHistRepository terminalHistRepository;
	
	@Autowired
	private TerminalRepository terminalRepository;
	
	public TerminalService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<TerminalHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<TerminalHistEntity> listaTerminalHist =
				terminalHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaTerminalHist;
	}
	
	@PutMapping
	public void salvar(List<TerminalHistEntity> terminalHistEntity) throws ObjetoNuloException {
		List<TerminalEntity> terminaisEntity;
		try {
			terminaisEntity = construirTerminais(terminalHistEntity);
			terminalRepository.saveAll(terminaisEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	public List<TerminalEntity> construirTerminais(List<TerminalHistEntity> terminaisHistEntity) throws ObjetoNuloException {
		List<TerminalEntity> listaEntity = new ArrayList<TerminalEntity>();
		
		if(terminaisHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de terminais para Alteração!");
		
		for (TerminalHistEntity terminalHist : terminaisHistEntity) {
			TerminalEntity terminal = new TerminalEntity();
			terminal.setCdAdqre(terminalHist.getCdAdqre());
			terminal.setDtAlt(terminalHist.getDtAlt());
			terminal.setDtIncl(terminalHist.getDtIncl());
			terminal.setDtInstaTerm(terminalHist.getDtInstaTerm());
			terminal.setIdStelo(terminalHist.getIdStelo());
			terminal.setIdSttusTerm(terminalHist.getIdSttusTerm());
			terminal.setIdTecno(terminalHist.getIdTecno());
			terminal.setNuTerm(terminalHist.getNuTerm());
			terminal.setSttus(terminalHist.getSttus());
			terminal.setTermPprioEc(terminalHist.getTermPprioEc());
			terminal.setUsuarAlt(terminalHist.getUsuarAlt());
			terminal.setUsuarIncl(terminalHist.getUsuarIncl());
			listaEntity.add(terminal);
		}
		
		return listaEntity;
	}

}
