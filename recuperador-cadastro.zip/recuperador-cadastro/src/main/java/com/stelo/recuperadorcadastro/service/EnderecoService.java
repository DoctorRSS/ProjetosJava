package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.EnderecoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EnderecoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EnderecoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EnderecoRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class EnderecoService {

	@Autowired
	private EnderecoHistRepository enderecoHistRepository;
	
	@Autowired
	private EnderecoRepository enderecoRepository;
	
	public EnderecoService() {
		// TODO Auto-generated constructor stub
	}
	
	
	@GetMapping
	public List<EnderecoHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<EnderecoHistEntity> listaEnderecoHist =
				enderecoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaEnderecoHist;
	}
	
	@PutMapping
	public void salvar(EnderecoHistEntity enderecoHistEntity) throws ObjetoNuloException{
		EnderecoEntity enderecoEntity;
		try {
			enderecoEntity = construirEndereco(enderecoHistEntity);
			enderecoRepository.save(enderecoEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	
	private EnderecoEntity construirEndereco(EnderecoHistEntity enderecoHistEntity) throws ObjetoNuloException {
		EnderecoEntity enderecoEntity = new EnderecoEntity();
		
		if(enderecoHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de endereço para Alteração!");
		
		enderecoEntity.setApelidoEndereco(enderecoHistEntity.getApelidoEndereco());
		enderecoEntity.setBairro(enderecoHistEntity.getBairro());
		enderecoEntity.setCep(enderecoHistEntity.getCep());
		enderecoEntity.setCidade(enderecoHistEntity.getCidade());
		enderecoEntity.setComplemento(enderecoHistEntity.getComplemento());
		enderecoEntity.setDataAlteracao(enderecoHistEntity.getDataAlteracao());
		enderecoEntity.setDataInclusao(enderecoHistEntity.getDataInclusao());
		enderecoEntity.setDestinatario(enderecoHistEntity.getDestinatario());
		enderecoEntity.setEstado(enderecoHistEntity.getEstado());
		enderecoEntity.setFonteDadosEndereco(enderecoHistEntity.getFonteDadosEndereco());
		enderecoEntity.setId(enderecoHistEntity.getId());
		enderecoEntity.setIdRelacionamento(enderecoHistEntity.getIdRelacionamento());
		enderecoEntity.setLogradouro(enderecoHistEntity.getLogradouro());
		enderecoEntity.setNumero(enderecoHistEntity.getNumero());
		enderecoEntity.setPais(enderecoHistEntity.getPais());
		enderecoEntity.setPreferencial(enderecoHistEntity.getPreferencial());
		enderecoEntity.setPrincipal(enderecoHistEntity.getPrincipal());
		enderecoEntity.setStatus(enderecoHistEntity.getStatus());
		enderecoEntity.setTipoEndereco(enderecoHistEntity.getTipoEndereco());
		enderecoEntity.setUsuarioAlteracao(enderecoHistEntity.getUsuarioAlteracao());
		enderecoEntity.setUsuarioInclusao(enderecoHistEntity.getUsuarioInclusao());
		
		return enderecoEntity;
	}


}
