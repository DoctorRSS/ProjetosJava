package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoPK;
import com.stelo.recuperadorcadastro.entity.cdto.StatusModuloTermEntity;

@Entity
@Table(name = "TB_MAQNA_CATAO", schema = "USR_CADU")
public class MaquinaCartaoEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private MaquinaCartaoPK maqnaCataoPK;
	
	@Column(name = "CD_ATIVCAO")
	private String codigoAtivacao;
	
	@Column(name ="STTUS_MAQNA")
	private char statusMaquina;
	
	@Column(name="STTUS")
	private Integer status;
	
	@Column(name="CD_SEQ_MAQNA_MDULO_TERM")
	private Long codSeqMaqna;
	
	@Column(name="CD_MAQNA_MDULO_TERM")
	private String codMaquinaModuloTerm;
	
//	@OneToOne
//	@JoinColumn(name = "ID_STTUS_MDULO_TERM")
//	private StatusModuloTermEntity statusModuloTermEntity;
	@Column(name = "ID_STTUS_MDULO_TERM")
	private Integer statusModuloTermEntity;
	
	@Column(name="USUAR_INCL")
	private String usuarioInclusao;
	
	@Column(name="USUAR_ALT")
	private String usuarioAlteracao;
	
	@Column(name="DT_INCL")
	private Date dataInclusao;
	
	@Column(name="DT_ALT")
	private Date dataAlteracao;
	
	@Column(name="DS_MOD_MAQNA")
	private String descricaoModelo;
	
	@Column(name="VR_MAQNA")
	private BigDecimal valorMaquina;
	
	@Column(name="CD_PDIDO")
	private Long codigoPedido;
	
	@Column(name="CD_MOD")
	private Integer codigoModelo;
	
	@Column(name="CD_CHIP")
	private String codigoChip;
	
	@Column(name="FLG_TRANS_REALZ")
	private Integer transferenciaRealizada;
	
	@Column(name="DS_MOTVO_ALT_STTUS")
	private String descMotivoAltStatus;
	
	@Column(name="STATUS_TERM")
	private Integer statusTerminal;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DT_ATIVACAO")
	private Date dataAtivacao;
	
	@Column(name="IC_TP_SOFT_MAQNA")
	private String icTpsoftmaqna;

	public MaquinaCartaoPK getMaqnaCataoPK() {
		return maqnaCataoPK;
	}

	public void setMaqnaCataoPK(MaquinaCartaoPK maqnaCataoPK) {
		this.maqnaCataoPK = maqnaCataoPK;
	}

	public String getCodigoAtivacao() {
		return codigoAtivacao;
	}

	public void setCodigoAtivacao(String codigoAtivacao) {
		this.codigoAtivacao = codigoAtivacao;
	}

	public char getStatusMaquina() {
		return statusMaquina;
	}

	public void setStatusMaquina(char statusMaquina) {
		this.statusMaquina = statusMaquina;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getCodSeqMaqna() {
		return codSeqMaqna;
	}

	public void setCodSeqMaqna(Long codSeqMaqna) {
		this.codSeqMaqna = codSeqMaqna;
	}

	public String getCodMaquinaModuloTerm() {
		return codMaquinaModuloTerm;
	}

	public void setCodMaquinaModuloTerm(String codMaquinaModuloTerm) {
		this.codMaquinaModuloTerm = codMaquinaModuloTerm;
	}

//	public StatusModuloTermEntity getStatusModuloTermEntity() {
//		return statusModuloTermEntity;
//	}
//
//	public void setStatusModuloTermEntity(StatusModuloTermEntity statusModuloTermEntity) {
//		this.statusModuloTermEntity = statusModuloTermEntity;
//	}

	public Integer getStatusModuloTermEntity() {
	return statusModuloTermEntity;
}

public void setStatusModuloTermEntity(Integer statusModuloTermEntity) {
	this.statusModuloTermEntity = statusModuloTermEntity;
}
	
	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public String getDescricaoModelo() {
		return descricaoModelo;
	}

	public void setDescricaoModelo(String descricaoModelo) {
		this.descricaoModelo = descricaoModelo;
	}

	public BigDecimal getValorMaquina() {
		return valorMaquina;
	}

	public void setValorMaquina(BigDecimal valorMaquina) {
		this.valorMaquina = valorMaquina;
	}

	public Long getCodigoPedido() {
		return codigoPedido;
	}

	public void setCodigoPedido(Long codigoPedido) {
		this.codigoPedido = codigoPedido;
	}

	public Integer getCodigoModelo() {
		return codigoModelo;
	}

	public void setCodigoModelo(Integer codigoModelo) {
		this.codigoModelo = codigoModelo;
	}

	public String getCodigoChip() {
		return codigoChip;
	}

	public void setCodigoChip(String codigoChip) {
		this.codigoChip = codigoChip;
	}

	public Integer getTransferenciaRealizada() {
		return transferenciaRealizada;
	}

	public void setTransferenciaRealizada(Integer transferenciaRealizada) {
		this.transferenciaRealizada = transferenciaRealizada;
	}

	public String getDescMotivoAltStatus() {
		return descMotivoAltStatus;
	}

	public void setDescMotivoAltStatus(String descMotivoAltStatus) {
		this.descMotivoAltStatus = descMotivoAltStatus;
	}

	public Integer getStatusTerminal() {
		return statusTerminal;
	}

	public void setStatusTerminal(Integer statusTerminal) {
		this.statusTerminal = statusTerminal;
	}

	public Date getDataAtivacao() {
		return dataAtivacao;
	}

	public void setDataAtivacao(Date dataAtivacao) {
		this.dataAtivacao = dataAtivacao;
	}

	public String getIcTpsoftmaqna() {
		return icTpsoftmaqna;
	}

	public void setIcTpsoftmaqna(String icTpsoftmaqna) {
		this.icTpsoftmaqna = icTpsoftmaqna;
	}

}
