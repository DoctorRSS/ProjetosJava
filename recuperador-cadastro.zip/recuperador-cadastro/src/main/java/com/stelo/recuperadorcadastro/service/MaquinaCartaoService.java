package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoPK;
import com.stelo.recuperadorcadastro.entity.cdto.repository.MaquinaCartaoHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.MaquinaCartaoRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class MaquinaCartaoService {

	@Autowired
	private MaquinaCartaoHistRepository maquinaCartaoHistRepository;
	
	@Autowired
	private MaquinaCartaoRepository maquinaCartaoRepository;
	
	public MaquinaCartaoService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<MaquinaCartaoHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<MaquinaCartaoHistEntity> listaMaquinaCartaoHist =
				maquinaCartaoHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaMaquinaCartaoHist;
	}
	
	@PutMapping
	public void salvar(MaquinaCartaoHistEntity maquinaCartaoHistEntity) throws ObjetoNuloException {
		MaquinaCartaoEntity maquinaCartaoEntity;
		try {
			maquinaCartaoEntity = construirMaquinaCartao(maquinaCartaoHistEntity);
			maquinaCartaoRepository.save(maquinaCartaoEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}

	private MaquinaCartaoEntity construirMaquinaCartao(MaquinaCartaoHistEntity maquinaCartaoHistEntity) throws ObjetoNuloException {
		MaquinaCartaoEntity maquinaCartaoEntity = new MaquinaCartaoEntity();
		MaquinaCartaoPK maqnaCataoPK = new MaquinaCartaoPK();		
		
		if(maquinaCartaoHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de terminais para Alteração!");
		
		maquinaCartaoEntity.setCodMaquinaModuloTerm(maquinaCartaoHistEntity.getCodMaquinaModuloTerm());
		maquinaCartaoEntity.setCodigoAtivacao(maquinaCartaoHistEntity.getCodigoAtivacao());
		maquinaCartaoEntity.setCodigoChip(maquinaCartaoHistEntity.getCodigoChip());
		maquinaCartaoEntity.setCodigoModelo(maquinaCartaoHistEntity.getCodigoModelo());
		maquinaCartaoEntity.setCodigoPedido(maquinaCartaoHistEntity.getCodigoPedido());
		maquinaCartaoEntity.setCodSeqMaqna(maquinaCartaoHistEntity.getCodSeqMaqna());
		maquinaCartaoEntity.setDataAlteracao(maquinaCartaoHistEntity.getDataAlteracao());
		//maquinaCartaoEntity.setDataAtivacao(maquinaCartaoHistEntity.getDataAtivacao());
		maquinaCartaoEntity.setDataInclusao(maquinaCartaoHistEntity.getDataInclusao());
		maquinaCartaoEntity.setDescMotivoAltStatus(maquinaCartaoHistEntity.getDescMotivoAltStatus());
		maquinaCartaoEntity.setDescricaoModelo(maquinaCartaoHistEntity.getDescricaoModelo());
		maqnaCataoPK.setNuSerie(maquinaCartaoHistEntity.getNuSerie());
		maqnaCataoPK.setNuTerm(maquinaCartaoHistEntity.getNuTerm());
		maquinaCartaoEntity.setMaqnaCataoPK(maqnaCataoPK);
		maquinaCartaoEntity.setStatus(maquinaCartaoHistEntity.getStatus());
		maquinaCartaoEntity.setStatusMaquina(maquinaCartaoHistEntity.getStatusMaquina());
		maquinaCartaoEntity.setStatusModuloTermEntity(maquinaCartaoHistEntity.getStatusModuloTermEntity());
		//maquinaCartaoEntity.setStatusTerminal(maquinaCartaoHistEntity.getStatusTerminal());
		maquinaCartaoEntity.setTransferenciaRealizada(maquinaCartaoHistEntity.getTransferenciaRealizada());
		maquinaCartaoEntity.setUsuarioAlteracao(maquinaCartaoHistEntity.getUsuarioAlteracao());
		maquinaCartaoEntity.setUsuarioInclusao(maquinaCartaoHistEntity.getUsuarioInclusao());
		maquinaCartaoEntity.setValorMaquina(maquinaCartaoHistEntity.getValorMaquina());
		return maquinaCartaoEntity;
	}


}
