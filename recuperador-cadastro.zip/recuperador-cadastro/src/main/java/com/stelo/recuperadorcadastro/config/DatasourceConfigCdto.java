package com.stelo.recuperadorcadastro.config;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
  basePackages = {"com.stelo.recuperadorcadastro.entity.cdto.repository", "com.stelo.recuperadorcadastro.entity.cdto"  } ,
		  entityManagerFactoryRef = "cdtoEntityManagerFactory", 
		  transactionManagerRef = "cdtoTransactionManager"
)
public class DatasourceConfigCdto {
	@Resource
	 private Environment env;

	@Bean(name="DataSourceCdto")
	public DataSource secondaryDataSource() {

		   DriverManagerDataSource dataSource = new DriverManagerDataSource();
		    dataSource.setDriverClassName(env.getProperty("spring.secondDatasource.driver-class-name"));
		    dataSource.setUrl(env.getProperty("spring.secondDatasource.url"));
		    dataSource.setUsername(env.getProperty("spring.secondDatasource.username"));
		    dataSource.setPassword(env.getProperty("spring.secondDatasource.password"));
		    return dataSource;
	}

	
	 @Autowired
	 @Bean(name = "cdtoEntityManagerFactory")
	  public LocalContainerEntityManagerFactoryBean cdtoEntityManagerFactory( EntityManagerFactoryBuilder builder, @Qualifier("DataSourceCdto") DataSource dataSource) 
	 	{
	    return
	      builder
	        .dataSource(dataSource)
	        .packages("com.stelo.recuperadorcadastro.entity.cdto")
	        .persistenceUnit("cdto")
	        .build();
	 	}
	 
	 @Autowired
	  @Bean(name = "cdtoTransactionManager")
	  public PlatformTransactionManager cdtoTransactionManager(
	    @Qualifier("cdtoEntityManagerFactory") EntityManagerFactory
	    cdtoEntityManagerFactory
	  ) {
	    return new JpaTransactionManager(cdtoEntityManagerFactory);
	  }
}
