package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="TB_ENDER_HIST", schema="USR_CADU")
public class EnderecoHistEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;
	
	@Column(name = "ID_ENDER")
	private Long id;
	
	@Column(name = "CEP")
	private String cep;
	
	@Column(name = "LOGDR")
	private String logradouro;
	
	@Column(name = "NU_ENDER")
	private String numero;
	
	@Column(name = "COMPL")
	private String complemento;
	
	@Column(name = "BAIRO")
	private String bairro;
	
	@Column(name = "CIDDE")
	private String cidade;
	
	@Column(name = "EST")
	private String estado;
	
	@Column(name = "PAIS")
	private String pais;
	
	@Column(name = "PREFC")
	private Integer preferencial;
	
	@Column(name = "ID_FONTE_DADOS")
	private Integer fonteDadosEndereco;
	
	@Column(name = "ID_TP_ENDER")
	private Integer tipoEndereco;
	
	@Column(name = "APLDO_ENDER")
	private String apelidoEndereco;
	
	@Column(name = "DSTNA")
	private String destinatario;
	
	@Column(name = "ID_RLCTO")
	private Long idRelacionamento;
	
	@Column(name = "USUAR_INCL")
	private String usuarioInclusao;
	
	@Column(name = "USUAR_ALT")
	private String usuarioAlteracao;
	
	@Column(name = "DT_INCL")
	private Date dataInclusao;
	
	@Column(name = "DT_ALT")
	private Date dataAlteracao;
	
	@Column(name = "STTUS")
	private Integer status;
	
	@Column(name = "PRINC")
	private Integer principal;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public Integer getPreferencial() {
		return preferencial;
	}

	public void setPreferencial(Integer preferencial) {
		this.preferencial = preferencial;
	}

	public Integer getFonteDadosEndereco() {
		return fonteDadosEndereco;
	}

	public void setFonteDadosEndereco(Integer fonteDadosEndereco) {
		this.fonteDadosEndereco = fonteDadosEndereco;
	}

	public Integer getTipoEndereco() {
		return tipoEndereco;
	}

	public void setTipoEndereco(Integer tipoEndereco) {
		this.tipoEndereco = tipoEndereco;
	}

	public String getApelidoEndereco() {
		return apelidoEndereco;
	}

	public void setApelidoEndereco(String apelidoEndereco) {
		this.apelidoEndereco = apelidoEndereco;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	public Long getIdRelacionamento() {
		return idRelacionamento;
	}

	public void setIdRelacionamento(Long idRelacionamento) {
		this.idRelacionamento = idRelacionamento;
	}

	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public Date getDataInclusao() {
		return dataInclusao;
	}

	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getPrincipal() {
		return principal;
	}

	public void setPrincipal(Integer principal) {
		this.principal = principal;
	}

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}
	

}
