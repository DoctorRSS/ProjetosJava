package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteEntity;
import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.SubAdquirenteHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.SubAdquirenteRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class SubAdquirenteService {

	@Autowired
	private SubAdquirenteHistRepository subAdquirenteHistRepository;
	
	@Autowired
	private SubAdquirenteRepository subAdquirenteRepository;
	
	public SubAdquirenteService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<SubAdquirenteHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<SubAdquirenteHistEntity> listaSubAdquirenteHist =
				subAdquirenteHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaSubAdquirenteHist;
	}
	
	@PutMapping
	public void salvar(SubAdquirenteHistEntity subAdquirenteHistEntity) throws ObjetoNuloException {
		SubAdquirenteEntity subAdquirenteEntity;
		try {
			subAdquirenteEntity = construirSubAdquirente(subAdquirenteHistEntity);
			subAdquirenteRepository.save(subAdquirenteEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
	}
	
	private SubAdquirenteEntity construirSubAdquirente(SubAdquirenteHistEntity subAdquirenteHistEntity) throws ObjetoNuloException {
		SubAdquirenteEntity subAdquirenteEntity = new SubAdquirenteEntity();
		
		if(subAdquirenteHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de Sub Adquirente para Alteração!");
		
		subAdquirenteEntity.setCdCicloFatura(subAdquirenteHistEntity.getCdCicloFatura());
		subAdquirenteEntity.setCdDepartamento(subAdquirenteHistEntity.getCdDepartamento());
		subAdquirenteEntity.setCdFilialLiquida(subAdquirenteHistEntity.getCdFilialLiquida());
		subAdquirenteEntity.setCdMoedaPagamento(subAdquirenteHistEntity.getCdMoedaPagamento());
		subAdquirenteEntity.setDsDepartamento(subAdquirenteHistEntity.getDsDepartamento());
		subAdquirenteEntity.setDtAlteracao(subAdquirenteHistEntity.getDtAlteracao());
		subAdquirenteEntity.setDtInclusao(subAdquirenteHistEntity.getDtInclusao());
		subAdquirenteEntity.setIdStelo(subAdquirenteHistEntity.getIdStelo());
		subAdquirenteEntity.setIdFilial(subAdquirenteHistEntity.getIdFilial());
		subAdquirenteEntity.setIdGrupoBin(subAdquirenteHistEntity.getIdGrupoBin());
		subAdquirenteEntity.setIdUsuarioAlteracao(subAdquirenteHistEntity.getIdUsuarioAlteracao());
		subAdquirenteEntity.setIdUsuarioInclusao(subAdquirenteHistEntity.getIdUsuarioInclusao());
		subAdquirenteEntity.setPcDepartamentoConta(subAdquirenteHistEntity.getPcDepartamentoConta());
		subAdquirenteEntity.setPercentualAntecipacaoFilial(subAdquirenteHistEntity.getPercentualAntecipacaoFilial());
		subAdquirenteEntity.setStatus(subAdquirenteHistEntity.getStatus());
		subAdquirenteEntity.setTaxaTransacao(subAdquirenteHistEntity.getTaxaTransacao());
		subAdquirenteEntity.setTpFatura(subAdquirenteHistEntity.getTpFatura());
		subAdquirenteEntity.setTpFilial(subAdquirenteHistEntity.getTpFilial());
		subAdquirenteEntity.setTpPamento(subAdquirenteHistEntity.getTpPamento());
		subAdquirenteEntity.setTpTransacao(subAdquirenteHistEntity.getTpTransacao());
		subAdquirenteEntity.setVlLimiteMinimoTransacaoAutorizada(subAdquirenteHistEntity.getVlLimiteMinimoTransacaoAutorizada());
		subAdquirenteEntity.setVlTaxaAntecipacao(subAdquirenteHistEntity.getVlTaxaAntecipacao());
		
		return subAdquirenteEntity;
	}

}
