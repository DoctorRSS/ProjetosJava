package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "TB_PSSOA_JURID_HIST", schema = "USR_CADU")
public class PessoaJuridicaHistEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;
	
	@Column(name = "ID_STELO")
	private Long idStelo;
	
	@Column(name = "CNPJ")
	private String cnpj;

	@Temporal(TemporalType.DATE)
	@Column(name = "DT_CNSTT")
	private Date dtConstituicao;

	@Column(name = "NM_FANTS")
	private String nomeFantasia;

	@Column(name = "RZ_SCIAL")
	private String razaoSocial;

	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Column(name = "DT_INCL")
	private Date dtInclusao;

	@Column(name = "USUAR_ALT")
	private String usuarioAlteracao;

	@Column(name = "USUAR_INCL")
	private String usuarioInclusao;

	@Column(name = "ID_FONTE_DADOS_CNPJ")
	private Integer idFonteDadosCnpjDm;

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public Date getDtConstituicao() {
		return dtConstituicao;
	}

	public void setDtConstituicao(Date dtConstituicao) {
		this.dtConstituicao = dtConstituicao;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public String getUsuarioAlteracao() {
		return usuarioAlteracao;
	}

	public void setUsuarioAlteracao(String usuarioAlteracao) {
		this.usuarioAlteracao = usuarioAlteracao;
	}

	public String getUsuarioInclusao() {
		return usuarioInclusao;
	}

	public void setUsuarioInclusao(String usuarioInclusao) {
		this.usuarioInclusao = usuarioInclusao;
	}

	public Integer getIdFonteDadosCnpjDm() {
		return idFonteDadosCnpjDm;
	}

	public void setIdFonteDadosCnpjDm(Integer idFonteDadosCnpjDm) {
		this.idFonteDadosCnpjDm = idFonteDadosCnpjDm;
	}
}
