package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_DM_STTUS_MDULO_TERM", schema = "USR_CADU")
public class StatusModuloTermEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_STTUS_MDULO_TERM")
	private Integer idStatusModTerm;
	
	@Column(name = "DS_STTUS_MDULO_TERM")
	private String dsStatusModTerm;
	
	public Integer getIdStatusModTerm() {
		return idStatusModTerm;
	}
	
	public void setIdStatusModTerm(Integer idStatusModTerm) {
		this.idStatusModTerm = idStatusModTerm;
	}
	
	public String getDsStatusModTerm() {
		return dsStatusModTerm;
	}
	
	public void setDsStatusModTerm(String dsStatusModTerm) {
		this.dsStatusModTerm = dsStatusModTerm;
	}
	
}

