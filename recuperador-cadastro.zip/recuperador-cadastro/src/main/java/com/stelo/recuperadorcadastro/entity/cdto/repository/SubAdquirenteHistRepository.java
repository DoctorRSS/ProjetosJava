package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteHistEntity;

@Repository
public interface SubAdquirenteHistRepository extends JpaRepository<SubAdquirenteHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_SUB_ADQRE_HIST where id_stelo = :idStelo ", nativeQuery=true)
	List<SubAdquirenteHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
