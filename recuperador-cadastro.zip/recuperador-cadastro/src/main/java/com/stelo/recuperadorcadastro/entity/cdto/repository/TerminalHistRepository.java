package com.stelo.recuperadorcadastro.entity.cdto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stelo.recuperadorcadastro.entity.cdto.TerminalHistEntity;

@Repository
public interface TerminalHistRepository extends JpaRepository<TerminalHistEntity, Long> {

	@Query(value = "select * from USR_CADU.TB_TERM_HIST where id_stelo = :idStelo ", nativeQuery=true)
	List<TerminalHistEntity> findHistoricoByIdStelo(@Param("idStelo") Long idStelo);
}
