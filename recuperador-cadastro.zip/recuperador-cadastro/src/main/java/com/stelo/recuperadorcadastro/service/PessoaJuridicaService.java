package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaJuridicaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaJuridicaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaJuridicaHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.PessoaJuridicaRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class PessoaJuridicaService {

	@Autowired
	private PessoaJuridicaRepository pessoaJuridicaRepository;
	
	@Autowired
	private PessoaJuridicaHistRepository pessoaJuridicaHistRepository;
	
	public PessoaJuridicaService() {
		
	}
	
	@GetMapping
	public List<PessoaJuridicaHistEntity> buscar(Long idStelo) {
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<PessoaJuridicaHistEntity> listaPessoaJuridicaHist = 
				pessoaJuridicaHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaPessoaJuridicaHist;
	}
	
	@PutMapping
	public void salvar(PessoaJuridicaHistEntity pessoaJuridicaHistEntity) throws ObjetoNuloException {
		PessoaJuridicaEntity pessoaJuridicaEntity;
		try {
			pessoaJuridicaEntity = construirPessoaJuridica(pessoaJuridicaHistEntity);
			pessoaJuridicaRepository.save(pessoaJuridicaEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private PessoaJuridicaEntity construirPessoaJuridica(PessoaJuridicaHistEntity pessoaJuridicaHistEntity) 
			throws ObjetoNuloException {
		PessoaJuridicaEntity pessoaJuridicaEntity = new PessoaJuridicaEntity();
		
		if(pessoaJuridicaHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de pessoa jurídica para Alteração!");
		
		pessoaJuridicaEntity.setCnpj(pessoaJuridicaHistEntity.getCnpj());
		pessoaJuridicaEntity.setDtAlteracao(pessoaJuridicaHistEntity.getDtAlteracao());
		pessoaJuridicaEntity.setDtConstituicao(pessoaJuridicaHistEntity.getDtConstituicao());
		pessoaJuridicaEntity.setDtInclusao(pessoaJuridicaHistEntity.getDtConstituicao());
		pessoaJuridicaEntity.setIdFonteDadosCnpjDm(pessoaJuridicaHistEntity.getIdFonteDadosCnpjDm());
		pessoaJuridicaEntity.setIdStelo(pessoaJuridicaHistEntity.getIdStelo());
		pessoaJuridicaEntity.setNomeFantasia(pessoaJuridicaHistEntity.getNomeFantasia());
		pessoaJuridicaEntity.setRazaoSocial(pessoaJuridicaHistEntity.getRazaoSocial());
		pessoaJuridicaEntity.setUsuarioAlteracao(pessoaJuridicaHistEntity.getUsuarioAlteracao());
		pessoaJuridicaEntity.setUsuarioInclusao(pessoaJuridicaHistEntity.getUsuarioInclusao());
		
		return pessoaJuridicaEntity;
	}

}
