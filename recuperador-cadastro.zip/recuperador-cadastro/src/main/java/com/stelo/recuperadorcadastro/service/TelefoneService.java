package com.stelo.recuperadorcadastro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.TelefoneEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TelefoneHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TelefoneHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.TelefoneRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class TelefoneService {

	@Autowired
	private TelefoneHistRepository telefoneHistRepository;
	
	@Autowired
	private TelefoneRepository telefoneRepository;
	
	public TelefoneService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<TelefoneHistEntity> buscar(Long idStelo){
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<TelefoneHistEntity> listaTelefoneHist =
				telefoneHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaTelefoneHist;
	}
	
	@PutMapping
	public void salvar(List<TelefoneHistEntity> telefoneHistEntity) throws ObjetoNuloException {
		List<TelefoneEntity> telefonesEntity;
		try {
			telefonesEntity = construirTelefones(telefoneHistEntity);
			telefoneRepository.saveAll(telefonesEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	

	private List<TelefoneEntity> construirTelefones(List<TelefoneHistEntity> telefonesHistEntity) throws ObjetoNuloException {
		List<TelefoneEntity> listaEntity = new ArrayList<TelefoneEntity>();
		
		if(telefonesHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de telefones para Alteração!");
		
		for(TelefoneHistEntity telefoneHist : telefonesHistEntity) {
			TelefoneEntity telefone = new TelefoneEntity();
			telefone.setDataAlteracao(telefoneHist.getDataAlteracao());
			telefone.setDataAlteracaoFonePrinc(telefoneHist.getDataAlteracaoFonePrinc());
			telefone.setDataFoneValido(telefoneHist.getDataFoneValido());
			telefone.setDataInclusao(telefoneHist.getDataInclusao());
			telefone.setDdd(telefoneHist.getDdd());
			telefone.setIcFonePrincipal(telefoneHist.getIcFonePrincipal());
			telefone.setIcFoneValido(telefoneHist.getIcFoneValido());
			telefone.setId(telefoneHist.getId());
			telefone.setIdFonteDados(telefoneHist.getIdFonteDados());
			telefone.setIdRelacionamento(telefoneHist.getIdRelacionamento());
			telefone.setIdTipoTelefone(telefoneHist.getIdTipoTelefone());
			telefone.setNumeroTelefone(telefoneHist.getNumeroTelefone());
			telefone.setStatus(telefoneHist.getStatus());
			telefone.setUsuarioAlteracao(telefoneHist.getUsuarioAlteracao());
			telefone.setUsuarioInclusao(telefoneHist.getUsuarioAlteracao());
			listaEntity.add(telefone);
		}
		
		return listaEntity;
	}

}
