package com.stelo.recuperadorcadastro.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.stelo.recuperadorcadastro.entity.cdto.PessoaHistEntity;
import com.stelo.recuperadorcadastro.service.PessoaService;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Controller
@RequestMapping("pessoa")
public class PessoaEndpoint {

	@Autowired
	private PessoaService pessoaService;
	
	@RequestMapping("/alterar")
	public ModelAndView novo(Long idStelo) {
		ModelAndView mv = new ModelAndView("pessoa/pessoa");
		PessoaHistEntity pessoaHistEntity = new PessoaHistEntity();
		mv.addObject("idStelo", idStelo);
		mv.addObject("pessoaHistEntity",pessoaHistEntity);
		return mv;
	}
	
	@GetMapping
	public ModelAndView buscarHistorico(Long idStelo) {
		ModelAndView mv = new ModelAndView("pessoa/pessoa");
		mv.addObject("idStelo", idStelo);
		List<PessoaHistEntity> listaPessoa = new ArrayList<PessoaHistEntity>();
		try {
			listaPessoa = pessoaService.buscar(idStelo);
		} catch(IdSteloObrigatorioException e) {
			mv.addObject("mensagemError", e.getMessage());
			return mv;
		}
		
		mv.addObject("pessoasHist",listaPessoa);
		
		return mv;
		
	}
	
	@PutMapping
	public ResponseEntity<?> salvar(PessoaHistEntity pessoaHistEntity){
		try {
			pessoaService.salvar(pessoaHistEntity);
		} catch (ObjetoNuloException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
		return ResponseEntity.ok("Sucesso");
	}
}
