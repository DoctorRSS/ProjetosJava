package com.stelo.recuperadorcadastro.utils;

import java.util.List;

import com.stelo.recuperadorcadastro.entity.cdto.ContaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.ContaPagamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EmailEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EmailHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EnderecoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EnderecoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.MaquinaCartaoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaFisicaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaRelacionamentoHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteEntity;
import com.stelo.recuperadorcadastro.entity.cdto.SubAdquirenteHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TelefoneEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TelefoneHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TerminalEntity;
import com.stelo.recuperadorcadastro.entity.cdto.TerminalHistEntity;

public class Conversor {

	public Conversor() {
		// TODO Auto-generated constructor stub
	}


}
