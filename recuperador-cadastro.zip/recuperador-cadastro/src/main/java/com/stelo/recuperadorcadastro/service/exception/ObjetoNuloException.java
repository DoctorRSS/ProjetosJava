package com.stelo.recuperadorcadastro.service.exception;

public class ObjetoNuloException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ObjetoNuloException(String message) {
		super(message);
	}
}
