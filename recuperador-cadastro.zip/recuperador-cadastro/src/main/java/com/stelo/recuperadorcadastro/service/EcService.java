package com.stelo.recuperadorcadastro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.stelo.recuperadorcadastro.entity.cdto.EcEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcHistEntity;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EcHistRepository;
import com.stelo.recuperadorcadastro.entity.cdto.repository.EcRepository;
import com.stelo.recuperadorcadastro.service.exception.IdSteloObrigatorioException;
import com.stelo.recuperadorcadastro.service.exception.ObjetoNuloException;

@Service
public class EcService {

	@Autowired
	private EcRepository ecRepository;
	
	@Autowired
	private EcHistRepository ecHistRepository;
	
	public EcService() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping
	public List<EcHistEntity> buscar(Long idStelo) {
		
		if(StringUtils.isEmpty(idStelo)) 
			throw new IdSteloObrigatorioException("Id Stelo não encontrado");
		
		List<EcHistEntity> listaEcHist = 
				ecHistRepository.findHistoricoByIdStelo(new Long(idStelo));
		
		return listaEcHist;
	}
	
	@PutMapping
	public void salvar(EcHistEntity ecHistEntity) throws ObjetoNuloException {
		EcEntity ecEntity;
		try {
			ecEntity = construirEc(ecHistEntity);
			ecRepository.save(ecEntity);
		} catch (ObjetoNuloException e) {
			e.printStackTrace();
		}
		
	}
	
	private EcEntity construirEc(EcHistEntity ecHistEntity) throws ObjetoNuloException {
		EcEntity ecEntity = new EcEntity();
		
		if(ecHistEntity==null) 
			throw new ObjetoNuloException("Não foi informado o histórico de Ec para Alteração!");
		
		ecEntity.setAntecAtivo(ecHistEntity.getAntecAtivo());
		ecEntity.setClientSecret(ecHistEntity.getClientSecret());
		ecEntity.setClientSecretAnterior(ecHistEntity.getClientSecretAnterior());
		ecEntity.setCodigoEcModuloTerminal(ecHistEntity.getCodigoEcModuloTerminal());
		ecEntity.setConfAutom(ecHistEntity.getConfAutom());
		ecEntity.setDataAlteracaoRegraMonitoracaoCancelamento(ecHistEntity.getDataAlteracaoRegraMonitoracaoCancelamento());
		ecEntity.setDtAlteracao(ecHistEntity.getDtAlteracao());
		ecEntity.setDtInclusao(ecHistEntity.getDtInclusao());
		ecEntity.setFlagCadastroModuloTerminal(ecHistEntity.getFlagCadastroModuloTerminal());
		ecEntity.setFlgEnvioEmailComp(ecHistEntity.isFlgEnvioEmailComp());
		ecEntity.setFlgEnvioEmailTrans(ecHistEntity.isFlgEnvioEmailTrans());
		ecEntity.setFlgGerenteResponsavel(ecHistEntity.getFlgGerenteResponsavel());
		ecEntity.setGerenteResponsavel(ecHistEntity.getGerenteResponsavel());
		ecEntity.setIdBanco(ecHistEntity.getIdBanco());
		ecEntity.setIdCateg(ecHistEntity.getIdCateg());
		ecEntity.setIdCli(ecHistEntity.getIdCli());
		ecEntity.setIdCliAnterior(ecHistEntity.getIdCliAnterior());
		ecEntity.setIdCnae(ecHistEntity.getIdCnae());
		ecEntity.setIdFormaCostituicao(ecHistEntity.getIdFormaCostituicao());
		ecEntity.setIdIndicacaoAntecipacao(ecHistEntity.getIdIndicacaoAntecipacao());
		ecEntity.setIdMatriz(ecHistEntity.getIdMatriz());
		ecEntity.setIdMerchant(ecHistEntity.getIdMerchant());
		ecEntity.setIdParceiro(ecHistEntity.getIdParceiro());
		ecEntity.setIdPlatf(ecHistEntity.getIdPlatf());
		ecEntity.setIdPorteEc(ecHistEntity.getIdPorteEc());
		ecEntity.setIdSituacaoEc(ecHistEntity.getIdSituacaoEc());
		ecEntity.setIdStelo(ecHistEntity.getIdStelo());
		ecEntity.setIdSubCateg(ecHistEntity.getIdSubCateg());
		ecEntity.setIdTpoIntgc(ecHistEntity.getIdTpoIntgc());
		ecEntity.setIdUsuarioAlteracao(ecHistEntity.getIdUsuarioAlteracao());
		ecEntity.setIdUsuarioInclusao(ecHistEntity.getIdUsuarioInclusao());
		ecEntity.setMcc(ecHistEntity.getMcc());
		ecEntity.setNmFaturaCartao(ecHistEntity.getNmFaturaCartao());
		ecEntity.setNuContrato(ecHistEntity.getNuContrato());
		ecEntity.setParceiroDistribuicao(ecHistEntity.getParceiroDistribuicao());
		ecEntity.setPercMarkupBanco(ecHistEntity.getPercMarkupBanco());
		ecEntity.setPercMarkupParceiro(ecHistEntity.getPercMarkupParceiro());
		ecEntity.setPercMarkupPlatf(ecHistEntity.getPercMarkupPlatf());
		ecEntity.setPeriodicidadeSaque(ecHistEntity.getPeriodicidadeSaque());
		ecEntity.setPrmssCanc(ecHistEntity.isPrmssCanc());
		ecEntity.setQuantidadeFuncionario(ecHistEntity.getQuantidadeFuncionario());
		ecEntity.setSaqueAutomatico(ecHistEntity.getSaqueAutomatico());
		ecEntity.setStatus(ecHistEntity.getStatus());
		ecEntity.setTipoRegraMonitoracaoCancelamento(ecHistEntity.getTipoRegraMonitoracaoCancelamento());
		ecEntity.setTpEc(ecHistEntity.getTpEc());
		ecEntity.setTpVendedor(ecHistEntity.getTpVendedor());
		
		return ecEntity;
	}

}
