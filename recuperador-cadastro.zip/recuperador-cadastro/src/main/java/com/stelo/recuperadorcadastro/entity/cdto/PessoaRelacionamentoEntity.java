package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//import com.stelo.recuperadorcadastro.entity.cdto.ContaEntity;
import com.stelo.recuperadorcadastro.entity.cdto.EcEntity;
//import com.stelo.recuperadorcadastro.entity.cdto.EmailEntity;
import com.stelo.recuperadorcadastro.entity.cdto.PessoaEntity;
//import com.stelo.recuperadorcadastro.entity.cdto.TelefoneEntity;

@Entity
@Table(name = "TB_PSSOA_RLCTO", schema = "USR_CADU")
public class PessoaRelacionamentoEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_RLCTO")
	private Long id;

	@ManyToOne
	@JoinColumn(name = "ID_STELO")
	private PessoaEntity idStelo;

	@ManyToOne
	@JoinColumn(name = "ID_EC")
	private EcEntity ec;

	@Column(name = "STTUS")
	private Long status;

	@Column(name = "ID_TP_RLCTO")
	private int idTipoRelacionamento;

	@Column(name = "ID_RLCTO_PGTO")
	private Long idRlctoPagamento;

//	@OneToMany(mappedBy = "relacionamento")
//	private List<EmailEntity> email;
//
//	@OneToMany(mappedBy = "relacionamento")
//	private List<TelefoneEntity> telefone;
//
//	@OneToMany(mappedBy = "relacionamento")
//	private List<ContaEntity> contas;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public PessoaEntity getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(PessoaEntity idStelo) {
		this.idStelo = idStelo;
	}

	public EcEntity getEc() {
		return ec;
	}

	public void setEc(EcEntity ec) {
		this.ec = ec;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public int getIdTipoRelacionamento() {
		return idTipoRelacionamento;
	}

	public void setIdTipoRelacionamento(int idTipoRelacionamento) {
		this.idTipoRelacionamento = idTipoRelacionamento;
	}

	public Long getIdRlctoPagamento() {
		return idRlctoPagamento;
	}

	public void setIdRlctoPagamento(Long idRlctoPagamento) {
		this.idRlctoPagamento = idRlctoPagamento;
	}

//	public List<EmailEntity> getEmail() {
//		return email;
//	}
//
//	public void setEmail(List<EmailEntity> email) {
//		this.email = email;
//	}
//
//	public List<TelefoneEntity> getTelefone() {
//		return telefone;
//	}
//
//	public void setTelefone(List<TelefoneEntity> telefone) {
//		this.telefone = telefone;
//	}
//
//	public List<ContaEntity> getContas() {
//		return contas;
//	}
//
//	public void setContas(List<ContaEntity> contas) {
//		this.contas = contas;
//	}

}
