package com.stelo.recuperadorcadastro.entity.cdto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TB_SUB_ADQRE_HIST", schema = "USR_CADU")
public class SubAdquirenteHistEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_HIST", nullable = false)
	private Long idHistorico;
	
	@Column(name = "TP_ALT", nullable = false)
	private Character tipoAlteracao;
	
	@Column(name = "DT_HIST", nullable = false)
	private Date dataHistorico;
	
	@Column(name = "ID_STELO")
	private Long idStelo;

	@Column(name = "USUAR_ALT")
	private String idUsuarioAlteracao;

	@Column(name = "USUAR_INCL")
	private String idUsuarioInclusao;

	@Column(name = "ID_TP_FAT")
	private Integer tpFatura;

	@Column(name = "ID_TP_FLIAL")
	private Integer tpFilial;

	@Column(name = "ID_TP_PGTO")
	private Integer tpPamento;

	@Column(name = "ID_TP_TRANS")
	private Integer tpTransacao;

	@Column(name = "VR_LIM_MIN_TRANS_AUTRZ")
	private BigDecimal vlLimiteMinimoTransacaoAutorizada;

	@Column(name = "VR_TX_ANTEC")
	private BigDecimal vlTaxaAntecipacao;

	@Column(name = "FLG_TX_TRANS")
	private Integer taxaTransacao;

	@Column(name = "ID_FLIAL")
	private Integer idFilial;

	@Column(name = "PC_DEP_CTA")
	private Integer pcDepartamentoConta;

	@Column(name = "ID_GRP_BIN")
	private Integer idGrupoBin;

	@Column(name = "ID_TP_CICLO_FAT")
	private Integer cdCicloFatura;

	@Column(name = "CD_DEPTO")
	private Integer cdDepartamento;

	@Column(name = "CD_FLIAL_LIQ")
	private Integer cdFilialLiquida;

	@Column(name = "CD_MOEDA_PGTO")
	private Integer cdMoedaPagamento;

	@Column(name = "DS_DEPTO")
	private String dsDepartamento;

	@Column(name = "DT_ALT")
	private Date dtAlteracao;

	@Column(name = "DT_INCL", nullable = false)
	private Date dtInclusao;

	@Column(name = "PC_ANTEC_FLIAL")
	private BigDecimal percentualAntecipacaoFilial;

	@Column(name = "STTUS", nullable = false)
	private Integer status;

	public Long getIdStelo() {
		return idStelo;
	}

	public void setIdStelo(Long idStelo) {
		this.idStelo = idStelo;
	}

	public String getIdUsuarioAlteracao() {
		return idUsuarioAlteracao;
	}

	public void setIdUsuarioAlteracao(String idUsuarioAlteracao) {
		this.idUsuarioAlteracao = idUsuarioAlteracao;
	}

	public String getIdUsuarioInclusao() {
		return idUsuarioInclusao;
	}

	public void setIdUsuarioInclusao(String idUsuarioInclusao) {
		this.idUsuarioInclusao = idUsuarioInclusao;
	}

	public Integer getTpFatura() {
		return tpFatura;
	}

	public void setTpFatura(Integer tpFatura) {
		this.tpFatura = tpFatura;
	}

	public Integer getTpFilial() {
		return tpFilial;
	}

	public void setTpFilial(Integer tpFilial) {
		this.tpFilial = tpFilial;
	}

	public Integer getTpPamento() {
		return tpPamento;
	}

	public void setTpPamento(Integer tpPamento) {
		this.tpPamento = tpPamento;
	}

	public Integer getTpTransacao() {
		return tpTransacao;
	}

	public void setTpTransacao(Integer tpTransacao) {
		this.tpTransacao = tpTransacao;
	}

	public BigDecimal getVlLimiteMinimoTransacaoAutorizada() {
		return vlLimiteMinimoTransacaoAutorizada;
	}

	public void setVlLimiteMinimoTransacaoAutorizada(BigDecimal vlLimiteMinimoTransacaoAutorizada) {
		this.vlLimiteMinimoTransacaoAutorizada = vlLimiteMinimoTransacaoAutorizada;
	}

	public BigDecimal getVlTaxaAntecipacao() {
		return vlTaxaAntecipacao;
	}

	public void setVlTaxaAntecipacao(BigDecimal vlTaxaAntecipacao) {
		this.vlTaxaAntecipacao = vlTaxaAntecipacao;
	}

	public Integer getTaxaTransacao() {
		return taxaTransacao;
	}

	public void setTaxaTransacao(Integer taxaTransacao) {
		this.taxaTransacao = taxaTransacao;
	}

	public Integer getIdFilial() {
		return idFilial;
	}

	public void setIdFilial(Integer idFilial) {
		this.idFilial = idFilial;
	}

	public Integer getPcDepartamentoConta() {
		return pcDepartamentoConta;
	}

	public void setPcDepartamentoConta(Integer pcDepartamentoConta) {
		this.pcDepartamentoConta = pcDepartamentoConta;
	}

	public Integer getIdGrupoBin() {
		return idGrupoBin;
	}

	public void setIdGrupoBin(Integer idGrupoBin) {
		this.idGrupoBin = idGrupoBin;
	}

	public Integer getCdCicloFatura() {
		return cdCicloFatura;
	}

	public void setCdCicloFatura(Integer cdCicloFatura) {
		this.cdCicloFatura = cdCicloFatura;
	}

	public Integer getCdDepartamento() {
		return cdDepartamento;
	}

	public void setCdDepartamento(Integer cdDepartamento) {
		this.cdDepartamento = cdDepartamento;
	}

	public Integer getCdFilialLiquida() {
		return cdFilialLiquida;
	}

	public void setCdFilialLiquida(Integer cdFilialLiquida) {
		this.cdFilialLiquida = cdFilialLiquida;
	}

	public Integer getCdMoedaPagamento() {
		return cdMoedaPagamento;
	}

	public void setCdMoedaPagamento(Integer cdMoedaPagamento) {
		this.cdMoedaPagamento = cdMoedaPagamento;
	}

	public String getDsDepartamento() {
		return dsDepartamento;
	}

	public void setDsDepartamento(String dsDepartamento) {
		this.dsDepartamento = dsDepartamento;
	}

	public Date getDtAlteracao() {
		return dtAlteracao;
	}

	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}

	public Date getDtInclusao() {
		return dtInclusao;
	}

	public void setDtInclusao(Date dtInclusao) {
		this.dtInclusao = dtInclusao;
	}

	public BigDecimal getPercentualAntecipacaoFilial() {
		return percentualAntecipacaoFilial;
	}

	public void setPercentualAntecipacaoFilial(BigDecimal percentualAntecipacaoFilial) {
		this.percentualAntecipacaoFilial = percentualAntecipacaoFilial;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(Long idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Character getTipoAlteracao() {
		return tipoAlteracao;
	}

	public void setTipoAlteracao(Character tipoAlteracao) {
		this.tipoAlteracao = tipoAlteracao;
	}

	public Date getDataHistorico() {
		return dataHistorico;
	}

	public void setDataHistorico(Date dataHistorico) {
		this.dataHistorico = dataHistorico;
	}

}
